# Spatial Mentor — Cursor Implementation Spec

## 1. Project Overview

**Project name:** Spatial Mentor  
**Tagline:** A synchronous remote teaching system for 3D CAD workflows where experts coach novices using embodied communication instead of relying only on screen sharing.

Spatial Mentor is a **desktop-first web application** for live expert-to-novice CAD mentoring. It supports a **1 expert : 1 learner** session focused on teaching 3D modeling tasks in tools like **Blender** or **Autodesk Fusion**.

The core idea is to help an expert remotely teach *how to manipulate 3D objects and tools* by combining:

- **Live embodied input from the expert**: hand gestures, voice, pointing, annotations
- **Live embodied feedback from the learner**: gesture responses, facial expression / engagement cues, quick verbal-style responses
- **Shared project-space overlays**: arrows, markers, labels, step highlights, region callouts
- **Gaze-inspired attention cues**: approximate attention target / focus hints rather than full scientific eye tracking

This is **not** just a video call with screenshare. The system treats the body as part of the interface:
- the expert demonstrates intent with gestures and voice-linked overlays
- the learner responds with gestures and lightweight facial/attention signals
- annotations are spatially anchored to the CAD viewport
- the system translates embodied actions into teachable visual guidance

---

## 2. Goal Relative to the Assignment

This design is optimized to score highly on the rubric by emphasizing:

1. **Novel embodied input/output**
   - webcam-based hand gesture recognition
   - facial expression / engagement inference
   - lightweight gaze/attention indication
   - spatial annotations tied to the 3D model area
   - live feedback loops between expert and learner

2. **Clear support for conveying expertise**
   - expert can point, circle, mark, arrow, speak, and gesture
   - learner can answer without interrupting flow using gesture responses and quick reaction buttons

3. **Clear support for receiving expertise**
   - learner gets spatial instructions directly on the project view
   - the system reduces ambiguity around “click here”, “drag this edge”, “look at this face”

4. **High execution quality**
   - robust MVP scope
   - fallback interaction modes when sensing is unreliable
   - polished interface, demo script, and implementation notes

---

## 3. Final Design Direction from the Sketches

Your sketches explore multiple combinations:
- verbal only
- verbal + gesture
- verbal + facial expression
- written annotations + gestures
- written annotations + verbal
- eye track + gesture + annotation

The strongest final concept is:

# **Annotation + Gesture + Attention + Learner Reaction**

This combines the most compelling parts of the sketches into one coherent system:
- expert teaches with **spoken explanation + hand gestures + drawing/annotation tools**
- learner reacts with **thumbs up / thumbs down / repeat / explain buttons**, optionally mirrored by detected gestures
- shared project view contains **anchored notes** like:
  - “select this area and round edges”
  - “drag this area to make it longer”
- attention/gaze cues help show whether the learner is looking at the intended region

This is the version Cursor should build.

---

## 4. Users and Session Structure

### Primary users
- **Expert**
  - experienced CAD user
  - teaches technique, workflow, and modeling intent

- **Learner**
  - novice CAD user
  - receives instruction, asks for clarification, and signals understanding

### Simultaneous users
- **1 expert and 1 learner** live at the same time

### Why 1:1 is best
- best for synchronous coaching
- technically feasible for a polished project
- easier to show that the system improves clarity and feedback quality
- avoids complexity that would reduce reliability during grading/demo

---

## 5. Device Scope

## Supported devices
### Primary target
- **Laptop / desktop browser with webcam and microphone**
- recommended for both expert and learner

### Optional support
- tablet as future extension, but not required for MVP

### Why desktop-first
CAD software is primarily used on larger screens with precision pointing. Desktop webcams also make gesture/facial tracking practical while keeping implementation realistic.

---

## 6. Expertise Being Conveyed

The system is designed for conveying **procedural CAD expertise**, especially:

- object selection
- face / edge / vertex manipulation
- extrusion / stretching / scaling
- rounding / beveling
- tool sequencing
- model-shape reasoning
- task correction (“not this surface; this one”)

### Recommended demo task
Use a simple object editing workflow such as:
1. Select a face or edge
2. Round or bevel a corner
3. Stretch one side
4. Adjust proportions
5. Confirm final model shape

This matches your sketches and is easy to demonstrate visually.

---

## 7. Core Product Concept

The interface has three major zones:

### A. Shared Project Area
Large central viewport showing the CAD scene or a simulated teaching scene.
This supports:
- live annotations
- arrows
- circles / highlights
- region labels
- transient pointer trails
- focus indicators

### B. Expert Panel
Shows:
- live webcam feed
- gesture state
- speaking state
- optional transcript snippets
- current active teaching tool

The expert can:
- speak
- point using gesture
- draw annotations
- drop markers
- highlight a region
- create step notes

### C. Learner Panel
Shows:
- live webcam feed
- learner reactions
- gesture/facial understanding cues
- quick response controls

The learner can:
- thumbs up
- thumbs down
- “please demonstrate again”
- “explain please”
- optionally use webcam-detected gestures for yes/no

### D. Right Tool Rail
Contains:
- Draw
- Arrow
- Marker
- Text note
- Focus region
- Clear all
- Session mode toggle
- Demo fallback controls

---

## 8. Embodied Interaction Model

## 8.1 Expert embodied input
The expert uses:
- **voice**
  - natural explanation while teaching
- **hand gestures**
  - point
  - pinch / hold
  - open palm for emphasis
  - directional motion to imply drag/stretch
- **body presence**
  - not a passive face cam; the body is part of how instruction is conveyed

### System interpretation of expert gestures
The app does not need full sign language understanding.
Instead, it maps a few robust gestures into interaction events:

- **Point / index-forward gesture**
  - activates a projected teaching cursor or spotlight

- **Pinch-and-move**
  - creates / drags a highlight anchor or arrow endpoint

- **Open palm**
  - toggles emphasis pulse on a selected region

- **Hold gesture for 1 second**
  - places a marker on the shared project view

These gestures should be intentionally limited so the prototype is reliable.

## 8.2 Learner embodied input
The learner uses:
- **thumbs up**
  - understood / continue
- **thumbs down**
  - confused / incorrect / stop
- **facial expression cues**
  - lightweight confidence or confusion estimate
- **attention cue**
  - whether learner appears to be looking toward the target region
- **optional voice substitute via buttons**
  - “explain please”
  - “please demonstrate again”

## 8.3 Output modalities
The system uses embodied output via:
- spatial overlay graphics
- movement-linked highlights
- animated arrows
- pulsing focus regions
- reaction badges
- optional audio cue when new instruction appears
- subtle haptics only if device supports it in the future; not required for MVP

---

## 9. Key Interaction Scenarios

## Scenario 1: Expert teaches a bevel/rounding step
1. Expert says: “Select this area and round the edge.”
2. Expert points toward the corner with a recognized hand gesture.
3. The system anchors a pulsing ring on that corner.
4. Expert adds a text annotation:
   - “select this area and round edges”
5. Learner looks at the region.
6. Learner gives thumbs up or taps “yes”.
7. Session proceeds.

## Scenario 2: Expert teaches drag/stretch operation
1. Expert says: “Drag this area to make it longer.”
2. Expert uses pinch-and-drag motion.
3. The system renders a directional arrow from source to target.
4. Learner responds “explain please” if needed.
5. Expert repeats using both gesture and visual annotation.

## Scenario 3: Learner confusion recovery
1. Learner shows thumbs down or presses “please demonstrate again”.
2. The system surfaces the learner reaction prominently for the expert.
3. Expert switches to draw mode and circles the exact region.
4. Expert restates the instruction.
5. Learner confirms with thumbs up.

---

## 10. MVP Definition

Cursor should build a polished MVP that fully works in demo conditions.

### MVP must include
- desktop web app
- two-role session: Expert and Learner
- shared project scene area
- two webcam panels
- annotation toolbar
- draw / arrow / marker / text tools
- clear all
- expert gesture recognition for a few simple gestures
- learner reaction system
- optional confusion/attention indicators
- sync between both users in real time
- demo-ready sample CAD scene or mock 3D object
- clean UI and onboarding instructions

### Nice-to-have if time allows
- speech-to-text captions
- auto-generated text note from voice
- persistent session timeline
- replay of teaching sequence
- stronger gaze estimation
- multiple objects / tutorial templates
- Blender/Fusion plugin integration

---

## 11. Technical Stack Recommendation

Use any strong modern stack, but this is the recommended one for Cursor.

## Frontend
- **Next.js 15**
- **React**
- **TypeScript**
- **Tailwind CSS**
- **Framer Motion**

## 3D / shared scene
- **Three.js**
- **@react-three/fiber**
- **@react-three/drei**

## Real-time communication
- **Liveblocks** or **Socket.IO**
- optional **WebRTC** for webcam streams if building full live peer video
- easier alternative for demo: local webcam panels + simulated dual-role mode in one browser

## Gesture / face / attention sensing
- **MediaPipe Tasks Vision**
- or **TensorFlow.js** + MediaPipe models
- hand landmark detection
- face landmark detection
- lightweight engagement/confusion heuristic
- optional cursor/gaze approximation from face/eye direction

## State / data
- **Zustand** for client state
- **Supabase** or **Firebase** for simple session persistence if needed

## UI components
- **shadcn/ui**

## Deployment
- **Vercel** for frontend
- **Supabase / Liveblocks / Pusher / Socket server** depending on chosen real-time solution

---

## 12. Recommended Architecture

## App modes
The app should support **two modes**:

### Mode A: Demo Single-Machine Split View
Best for critique/demo reliability.
- one machine
- one browser window
- both Expert and Learner panels visible
- can simulate both sides
- allows sensor testing without networking complexity

### Mode B: Real Remote Session
- two browsers
- expert joins session
- learner joins session
- sync annotations and reactions over network

### Why both modes matter
This ensures the project remains robust even if network/video issues happen during grading.

---

## 13. Functional Requirements

## 13.1 Session flow
- landing page
- create/join session
- choose role: Expert or Learner
- webcam permission request
- optional mic permission request
- enter teaching room

## 13.2 Shared project area
- render a simple editable 3D object
- allow expert overlays on top of the scene
- support annotation layering
- show active focus target
- sync all overlay changes live

## 13.3 Annotation tools
- draw freehand
- arrow tool
- marker tool
- text note tool
- focus halo tool
- clear all button
- undo last action if possible

## 13.4 Expert sensing features
- webcam panel
- detect simple hand gestures
- map gestures to UI actions
- show current detected gesture label
- fallback manual buttons if gesture fails

## 13.5 Learner feedback features
- thumbs up/down via buttons
- optional thumbs up/down gesture detection
- quick buttons:
  - yes
  - no
  - explain please
  - please demonstrate again
- optional engagement status:
  - attentive
  - uncertain
  - disengaged

## 13.6 Attention / gaze-inspired cue
This does **not** need to be scientific eye tracking.
A practical MVP is:
- estimate whether the learner’s face is oriented toward the shared project region
- if the expert has marked a region, show whether learner appears to be attending to it
- visualize as:
  - green = likely looking at target
  - amber = uncertain
  - gray = not enough signal

## 13.7 Accessibility / resilience
- all gesture actions must have clickable UI alternatives
- all learner responses must be button-accessible
- if webcam permission denied, still allow manual demo mode
- if gesture detection fails, the session remains usable

---

## 14. Non-Functional Requirements

- polished visual design
- responsive layout for laptop
- low-friction onboarding
- reliable core demo path
- graceful degradation
- clear labels and status feedback
- performant enough for live interaction
- no blocking dependency on perfect ML inference

---

## 15. UX and Visual Design Guidelines

The UI should feel polished, modern, and presentation-ready.

### Layout
- large central project area
- bottom split for expert/learner panels
- right vertical tools panel
- clear section labels
- active mode badges
- soft shadows, rounded corners, strong spacing

### Suggested visual language
- expert accents: magenta / pink
- learner accents: green
- project annotations: bright pink for notes and callouts
- neutral background with strong contrast

### Motion design
Use animation carefully:
- pulsing focus region
- animated arrow draw-in
- reaction badge pop-in
- gesture recognized confirmation
- fade-out temporary marks

---

## 16. Information Architecture / Pages

## Page 1: Landing
- title
- project description
- Create Session
- Join Session
- Demo Mode

## Page 2: Permissions / Setup
- webcam preview
- gesture calibration
- learner/expert role selection
- device status checks

## Page 3: Session Room
Contains:
- shared project area
- expert panel
- learner panel
- tools rail
- session status
- reactions and overlays

## Page 4: Optional Debrief / Replay
- summary of annotations
- reaction history
- screenshots of key teaching moments

---

## 17. Suggested File Structure

```txt
app/
  page.tsx
  setup/page.tsx
  session/[id]/page.tsx
components/
  layout/
  session/
  webcam/
  annotations/
  learner/
  expert/
  project/
  ui/
lib/
  mediapipe/
  gestures/
  face/
  attention/
  sync/
  store/
  utils/
types/
public/
```

More concrete structure:

```txt
components/
  project/SharedViewport.tsx
  project/ObjectScene.tsx
  project/AnnotationLayer.tsx
  webcam/ExpertCamPanel.tsx
  webcam/LearnerCamPanel.tsx
  expert/ExpertGestureState.tsx
  learner/LearnerReactionPanel.tsx
  session/Toolbar.tsx
  session/RoomHeader.tsx
  session/AttentionIndicator.tsx
lib/
  gestures/recognizeHandGesture.ts
  face/estimateConfusion.ts
  attention/estimateAttentionToTarget.ts
  sync/sessionChannel.ts
  store/useSessionStore.ts
```

---

## 18. Core Data Model

```ts
type Role = "expert" | "learner";

type AnnotationType = "draw" | "arrow" | "marker" | "text" | "focus";

type Point = {
  x: number;
  y: number;
};

type Annotation = {
  id: string;
  type: AnnotationType;
  points?: Point[];
  start?: Point;
  end?: Point;
  position?: Point;
  text?: string;
  color: string;
  createdBy: Role;
  createdAt: number;
};

type LearnerReaction =
  | "yes"
  | "no"
  | "thumbs_up"
  | "thumbs_down"
  | "explain_please"
  | "demonstrate_again";

type AttentionState = "target_locked" | "uncertain" | "away" | "no_signal";

type GestureState =
  | "idle"
  | "point"
  | "pinch"
  | "open_palm"
  | "thumbs_up"
  | "thumbs_down";
```

---

## 19. Gesture Recognition Rules

Keep this intentionally small.

## Expert gestures
- **point**
  - show teaching pointer
- **pinch**
  - drag annotation anchor or arrow endpoint
- **open_palm**
  - emphasize current target
- **hold point**
  - place marker

## Learner gestures
- **thumbs_up**
  - understood
- **thumbs_down**
  - confused

### Reliability rule
Use confidence thresholds and temporal smoothing:
- do not trigger on a single noisy frame
- require gesture confidence for ~300–500 ms
- debounce repeat triggers

---

## 20. Attention / Facial Heuristics

This project should avoid overclaiming scientific accuracy.

Implement lightweight heuristics such as:
- face present / not present
- head roughly oriented toward screen center or shared project target
- eyebrows / mouth openness / head tilt used only as optional confusion hints
- always label these as **estimated cues**, not definitive truths

UI examples:
- “Learner appears focused on target”
- “Learner may need clarification”
- “No reliable attention signal”

This is safer, more honest, and stronger academically.

---

## 21. Real-Time Sync Strategy

Minimum sync entities:
- annotations
- active tool
- focus target
- learner reactions
- gesture state labels
- attention state

Recommended implementation:
- use Liveblocks or Socket.IO room per session
- sync annotation objects and transient presence data
- presence state can contain:
  - cursor
  - active gesture
  - current reaction
  - attention state

---

## 22. How This Meets the Assignment Strongly

### Novel embodied input/output
- embodied input is central, not decorative
- gestures and attention are transformed into instruction support
- learner’s body feedback becomes part of the teaching loop

### Support for experts conveying expertise
- expert has multiple simultaneous communication channels
- can spatially disambiguate targets on the model
- can recover from learner confusion quickly

### Support for novices receiving expertise
- novice gets anchored, visible, multimodal guidance
- quick reactions reduce communication burden
- focus cues reduce ambiguity

### Strong prototype strategy
- desktop-first
- constrained, polished gestures
- graceful fallback interactions
- demo mode prevents failure during presentation

---

## 23. Implementation Plan for Cursor

## Phase 1 — Scaffold and layout
Build:
- Next.js app
- landing/setup/session pages
- responsive layout
- shared project area
- expert and learner panels
- right toolbar

## Phase 2 — Shared scene + overlays
Build:
- 3D object scene
- annotation canvas overlay
- tools: draw, arrow, marker, text, clear
- local state

## Phase 3 — Real-time sync
Build:
- session creation/join
- shared annotation syncing
- shared reactions
- shared focus state

## Phase 4 — Webcam + sensing
Build:
- webcam capture components
- MediaPipe hand tracking
- simple expert gesture detection
- learner thumbs up/down detection
- visible gesture labels

## Phase 5 — Attention/facial cues
Build:
- face landmark detection
- estimated attention indicator
- optional confusion badge

## Phase 6 — Polish
Build:
- animations
- onboarding copy
- fallback controls
- keyboard support
- bug fixes
- demo data

## Phase 7 — Documentation and demo support
Build:
- README
- setup instructions
- architecture diagram
- demo script
- limitations section

---

## 24. Strict Cursor Build Priorities

Cursor should prioritize in this exact order:

1. clean session UI
2. shared project scene
3. annotation tools
4. learner reaction buttons
5. local webcam panels
6. expert gesture recognition
7. learner gesture recognition
8. attention indicator
9. real-time sync
10. polish and demo mode

Reason: the project must always remain demoable even if sensing is imperfect.

---

## 25. Demo Script

Use this exact 2–3 minute demo flow.

1. Open Spatial Mentor
2. Enter Demo Mode
3. Show expert and learner panels
4. Show shared CAD object
5. Expert says:
   - “Select this area and round the edge.”
6. Use point gesture or manual focus tool to mark a corner
7. Add text note:
   - “select this area and round edges”
8. Learner gives thumbs up
9. Expert says:
   - “Drag this area to make it longer.”
10. Draw an arrow showing direction
11. Learner presses “please demonstrate again”
12. Expert repeats using both gesture and annotation
13. Show attention indicator updating
14. End by explaining that the system converts embodied teaching into spatial guidance

---

## 26. Evaluation Notes for Final Presentation / Write-Up

Your presentation/write-up should explicitly argue:

### Why this is better than plain screen sharing
- screen sharing often leaves spatial ambiguity
- embodied cues help communicate manipulation intent
- learner reactions are visible without interrupting flow
- the expert can teach with their body as well as words

### Why the chosen sensing is appropriate
- webcam-based sensing is accessible and feasible
- gestures align naturally with spatial modeling tasks
- learner attention/reaction improves pacing

### Why the design is constrained
- fewer gestures = more reliability
- desktop-first = better fit for CAD
- 1:1 session = polished experience

---

## 27. Limitations to Acknowledge Honestly

Include these in the final project documentation:
- gesture recognition is approximate and may vary by lighting/camera
- attention estimation is heuristic, not true eye tracking
- prototype focuses on simple modeling instruction, not full CAD integration
- manual fallbacks are intentionally included for robustness

These limitations do **not** weaken the concept if framed correctly.

---

## 28. Stretch Features

Only after MVP is complete, consider:
- speech-to-text note generation
- AI summarization of lesson steps
- playback of expert annotations
- plugin bridge to Blender
- collaborative object manipulation
- haptic phone companion for learner confirmations

---

## 29. README Requirements Cursor Should Also Produce

Cursor should create a high-quality README with:
- project overview
- why it matters
- setup steps
- tech stack
- how to run locally
- permissions needed
- demo mode instructions
- gesture list
- known limitations
- future work

---

## 30. Direct Build Instruction for Cursor

Use this as the operative instruction:

> Build a polished desktop-first Next.js + TypeScript web app called Spatial Mentor. The app supports synchronous remote CAD teaching between one expert and one learner. The UI must include a large shared 3D project area, an Expert webcam panel, a Learner webcam panel, and a right-side annotation toolbar. Implement annotation tools (draw, arrow, marker, text, focus, clear), learner response controls (yes, no, explain please, please demonstrate again, thumbs up, thumbs down), webcam-based gesture recognition using MediaPipe for a small reliable gesture set, and a lightweight learner attention/confusion indicator. Support a demo mode that works on one machine and a live session mode with real-time sync. Prioritize polish, graceful fallbacks, and a strong embodied interaction story over trying to build full CAD software integration.

---

## 31. File-by-File Build Checklist for Cursor

### app/page.tsx
- landing page
- project summary
- CTA buttons

### app/setup/page.tsx
- permissions
- role selection
- calibration / device checks

### app/session/[id]/page.tsx
- main session layout
- connect store + sync

### components/project/SharedViewport.tsx
- container for 3D object and overlays

### components/project/ObjectScene.tsx
- simple editable model or demo object

### components/project/AnnotationLayer.tsx
- draw arrows, markers, text notes, focus regions

### components/webcam/ExpertCamPanel.tsx
- webcam feed
- gesture label
- fallback buttons

### components/webcam/LearnerCamPanel.tsx
- webcam feed
- learner state
- reaction display

### components/learner/LearnerReactionPanel.tsx
- quick reactions
- thumb buttons
- explain/demonstrate buttons

### components/session/Toolbar.tsx
- annotation tools
- clear all
- current tool display

### components/session/AttentionIndicator.tsx
- learner target attention badge

### lib/gestures/recognizeHandGesture.ts
- stable gesture logic

### lib/face/estimateConfusion.ts
- lightweight face-based status heuristic

### lib/attention/estimateAttentionToTarget.ts
- focus-state heuristic

### lib/store/useSessionStore.ts
- client state

### lib/sync/sessionChannel.ts
- room syncing

---

## 32. Final Standard for “A-grade” Execution

Before considering the project finished, make sure it achieves all of these:

- visually polished
- clear interaction story in under 30 seconds
- embodied sensing is central to the system
- annotations are smooth and readable
- learner reactions are visible and useful
- system works even when ML sensing is imperfect
- demo can be run confidently in class
- documentation is strong enough that another developer could continue the project

---

## 33. Final Note

This project should be framed as a **teaching interface for embodied remote CAD mentorship**, not merely a collaboration app. The strongest version of the project is the one where body, gesture, attention, and annotation all work together to make expert knowledge visible and actionable for a novice.
